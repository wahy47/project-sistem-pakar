<footer id="footer">

    <div class="container d-md-flex py-4">

        <div class="me-md-auto text-center text-md-start">
            <div class="copyright">
                &copy; Copyright
            </div>
            <div class="credits">

            </div>
        </div>
    </div>
</footer><!-- End Footer -->
