<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TesStatusController extends Controller
{
    //
}
